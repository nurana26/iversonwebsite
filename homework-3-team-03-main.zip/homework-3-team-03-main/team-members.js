document.addEventListener("DOMContentLoaded", function() {
    var teamMembers = document.querySelectorAll(".team-member");

    for (var i = 0; i < teamMembers.length; i++) {
        teamMembers[i].addEventListener("click", function() {
            alert("You clicked on " + this.querySelector("h2").textContent + "!");
        });
    }

    var socialIcons = document.querySelectorAll(".social-icons a");
    for (var i = 0; i < socialIcons.length; i++) {
        socialIcons[i].addEventListener("mouseover", function() {
            this.style.transform = "scale(1.2)";
        });

        socialIcons[i].addEventListener("mouseout", function() {
            this.style.transform = "scale(1)";
        });
    }
    for (var j = 0; j < socialIcons.length; j++) {
        socialIcons[j].addEventListener("click", function (event) {
            event.stopPropagation();
        });
    }
});


