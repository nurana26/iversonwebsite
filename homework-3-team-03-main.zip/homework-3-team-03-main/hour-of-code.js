document.addEventListener("DOMContentLoaded", function() {
    console.log("Welcome to the Hour of Code Event Page!");
});
